NEXORA WEBSITE STARTER
======================

Included:
- index.html: responsive single-page business website with Home, Services, About, Portfolio, Pricing, Process, FAQ, and Contact sections.
- Brand styling: black, white, gold.
- Concept projects are clearly labeled as fictional concept work.
- Pricing is presented as introductory estimates, not guaranteed quotes.
- Contact form uses the visitor's email app (mailto); it does not store submissions.

IMPORTANT BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Find: REPLACE-WITH-YOUR-REAL-EMAIL@example.com
3. Replace it with your actual email address.
4. Check all copy, prices, service scope, and contact details.
5. Test the site on your phone and confirm the inquiry opens the correct email app.
6. Do not publish a false address, fake testimonials, or claims about clients/results.

HOW TO PUBLISH FREE WITH GITHUB PAGES (PHONE-FRIENDLY)
1. Create/sign into a GitHub account at https://github.com/
2. Create a new PUBLIC repository named nexora-site (or another available name).
3. Upload index.html to the repository's root. If GitHub's mobile interface offers Add file > Upload files, use it.
4. Open the repository Settings > Pages.
5. Under the build/deployment source, select Deploy from a branch, choose main and /(root), then Save.
6. Wait for deployment. In Settings > Pages, use the displayed Visit site link.
7. Test the published URL on your phone. The site is not live until you complete these steps.
8. Later, you can connect a domain you own through the Pages settings and configure DNS as instructed by GitHub.

GitHub Pages publishes static files and is suitable for this starter site. The contact form opens the user's email app; it is not a server-backed form. For a form that stores submissions, add a form service only after checking its current pricing, privacy terms, and availability.

BRAND FOUNDATION
- Name: NEXORA
- Tagline: Ideas Into Impact.
- Positioning: AI-assisted product advertisements, short-form promotional videos, and digital creatives.
- Colors: Black #0B0B0D; White #FFFFFF; Gold #D4AF37; Charcoal #202024; Soft Gold #E8D9A8.
- Initial niche: small ecommerce brands selling skincare/beauty, technology accessories, and fashion/lifestyle products.
- Trust rule: identify all fictional brands and concept work clearly; do not claim client results, testimonials, or awards that do not exist.

BUSINESS REGISTRATION NOTE
This starter site does not register a business or reserve the NEXORA name. Check name availability and the current process/fees with Nigeria's Corporate Affairs Commission before representing the name as registered:
https://www.cac.gov.ng/services/business-name
